#imports necesarios para que el codigo funcione
import sys
from gpiozero import PWMLED
from time import sleep
import RPi.GPIO as GPIO, time
import signal
from gpiozero import LED, Button
from threading import Thread
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

channel = 18 #Variable para tener el PIN del sensor de sonido
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.IN)  #PIN del sensor de sonido
GPIO.setup(27, GPIO.OUT) #PIN del LED Alarma
GPIO.setup(12, GPIO.OUT) #PIN del LED del Parque

LED1 = LED(12) #PIN del LED del Parque

LED2 = LED(22) #PIN del LED de las Farolas

PAHT_CRED = '/home/pi/iot/cred.json' #Ubicación Archivo cred.json para conexion con Fire Base
URL_DB = 'https://conmutacion-final-93db1.firebaseio.com/' #URL de la base de datos de Fire Base
# Referencia para el arbol de creacion de la Base de Datos de Fire Base
REF_CIUDAD = 'ciudad'
REF_LUCES = 'luces'
REF_SENSORES = 'sensores'
REF_LUZ_FAROLAS = 'luz_farolas'
REF_LUZ_PARQUE = 'luz_parque'
REF_LUZ_CICLO = 'luz_ciclo'
REF_SENSOR_SONIDO = 'sensor_sonido'

class IOT():

    def __init__(self):
        cred = credentials.Certificate(PAHT_CRED)
        firebase_admin.initialize_app(cred, {
            'databaseURL': URL_DB
        })

        self.refHome = db.reference(REF_CIUDAD)

        #self.estructuraInicialDB()  
        #Creaccion de los hijos (arbol) para estructura de la base de datos
        self.refLuces = self.refHome.child(REF_LUCES)
        self.refLuzFarolas = self.refLuces.child(REF_LUZ_FAROLAS)
        self.refLuzParque = self.refLuces.child(REF_LUZ_PARQUE)
        self.refLuzCiclo = self.refLuces.child(REF_LUZ_CICLO)
        self.refSensores = self.refHome.child(REF_SENSORES)
        self.refSensoresSonido = self.refSensores.child(REF_SENSOR_SONIDO)
    #Metodo que crea la estructura de la base de datos
    def estructuraInicialDB(self):
        self.refHome.set({
            'luces': {
                'luz_parque':True,
                'luz_farolas':True,
                'luz_ciclo':True
            },
            'sensores':{
                'sensor_sonido':True
            }
        })

    #Metodo del que se crea un hilo para el ciclo del LED del parque 
    def cicloStart(self):
        R, i = [], 0
        estado_anterior_ciclo = self.refLuzCiclo.get() #Instruccion para tomar el estado de la variable en la BD  
        R.append(estado_anterior_ciclo)
        while True:
            estado_actual_ciclo = self.refLuzCiclo.get() 
            R.append(estado_actual_ciclo)
            if R[i] != R[-1]:
                #ciclo en donde se realiza la accion de la funcion
                while estado_actual_ciclo:
                    GPIO.output(12, True)
                    time.sleep(1)
                    GPIO.output(12, False)
                    time.sleep(0.4)
                    GPIO.output(12, True)
                    time.sleep(1)
                    GPIO.output(12, False)
                    time.sleep(0.4)
                    estado_actual_ciclo = self.refLuzCiclo.get()
                

            del R[0]
            i = i + i

            time.sleep(0.4)
    #Metodo que controla los LEDs de Parque y Farolas
    def ledControlGPIO(self, estado, led):
        if estado:
            led.on() #Prender
            print('Luces Encendida')
        else:
            led.off() #Apagar
            print('Luces Apagada')
            
    #Metodo del que se crea un hilo para el prender y apagar los LEDs del Parque y Farolas
    def lucesStart(self):

        E, i = [], 0
        R, j = [], 0
	
        estado_anterior_parque = self.refLuzParque.get()
        self.ledControlGPIO(estado_anterior_parque,LED1)
        estado_anterior_farolas = self.refLuzFarolas.get()
        self.ledControlGPIO(estado_anterior_farolas,LED2)

        

        E.append(estado_anterior_farolas)
        R.append(estado_anterior_parque)

        while True:
          estado_actual_farolas = self.refLuzFarolas.get()
          E.append(estado_actual_farolas)

          estado_actual_parque = self.refLuzParque.get()
          R.append(estado_actual_parque)

          if E[i] != E[-1]:
           self.ledControlGPIO(estado_actual_farolas,LED2)

          if R[j] != R[-1]:
           self.ledControlGPIO(estado_actual_parque,LED1)

          del E[0]
          del R[0]

          i = i + i
          j = j + j
          sleep(0.4)
    #Metodo para que cuando el sensor de sonido reciba una señal prenda un LED e imprima un mensaje
    def callback(channel):

        if GPIO.input(channel):
            GPIO.output(27, True)
            print("Accidente Detectado!")
            time.sleep(1)

        else:
            GPIO.output(27, True)
            print("Accidente Detectado!")
            time.sleep(4)


            
    GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)#Linea necesaria para que el sensor de sonido funcione
    GPIO.add_event_callback(channel, callback)#Linea para añadir el metodo callback al sensor
    
    #Metodo del que se crea un hilo para el funcionamiento del sensor de sonido
    def sensorStart(self):
        # Cuerpo del codigo
        try:
            R, i = [], 0
            estado_anterior_alarma = self.refSensoresSonido.get()
            R.append(estado_anterior_alarma)
            while True:
                print("Sin Accidentes")
                estado_actual_alarma = self.refSensoresSonido.get()
                R.append(estado_actual_alarma)
                if R[i] != R[-1]:
                   GPIO.output(27, False)

                del R[0]
                i = i + i

                time.sleep(1)
        # Cerramos el script
        except KeyboardInterrupt:
            GPIO.cleanup()


print ('START !')#Linea que muestra cuando empieza el programa 
iot = IOT()#Crea una instancia de la clase, lo que permite que el programa arranque con su funcionalidad

#Creacion de los hilos

#Hilo del ciclo del led del Parque
subproceso_ciclo = Thread(target=iot.cicloStart)
subproceso_ciclo.daemon = True
subproceso_ciclo.start()


#Hilo del control de los LEDs del Parque y Farolas
subproceso_led = Thread(target=iot.lucesStart)
subproceso_led.daemon = True
subproceso_led.start()

#Hilo del sensor de sonido
subproceso_btn = Thread(target=iot.sensorStart)
subproceso_btn.daemon = True
subproceso_btn.start()
signal.pause()


