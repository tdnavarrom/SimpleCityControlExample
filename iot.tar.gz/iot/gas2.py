import RPi.GPIO as GPIO, time
import firebase_admin 
from firebase_admin import credentials, db
# Declaramos
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.IN)
GPIO.setup(27, GPIO.OUT)
cred = credentials.Certificate('/home/pi/iot/cred.json')
firebase_admin.intialize_app(cred, {
'databaseURL' : 'https://conmutacion-final.firebaseio.com/'
})
refEjemplo= db.reference('ejemplo')

# Cuerpo del codigo
try:
    while True:
        if GPIO.input(18):
           print("Sin problemas")
           GPIO.output(27, False)
           time.sleep(2)
	   refEjemplo.set('Sin Problemas')
        if GPIO.input(18)!=1:
           print("GASSSSSS")
           GPIO.output(27, False)
           time.sleep(2)
           GPIO.output(27, True)
           refEjemplo.set('GASSSSSS')
# Cerramos el script
except KeyboardInterrupt:
    print "See you later in #artDuino"
    GPIO.cleanup()
