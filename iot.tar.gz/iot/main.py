#!/usr/bin/python
# -*- coding: utf-8 -*-
# autor: Jefferson Rivera
# Abril de 2018
# email: riverajefer@gmail.com

import sys
from time import sleep
import signal
from gpiozero import LED, Button
from threading import Thread
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

LED1 = LED(17)
LED2 = LED(22)
BUTTON = Button(27)

PAHT_CRED = '/home/pi/iot/cred.json'
URL_DB = 'https://conmutacion-final.firebaseio.com/'
REF_HOME = 'home'
REF_LUCES = 'luces'
REF_BOTONES = 'botones'
REF_LUZ_SALA = 'luz_sala'
REF_LUZ_COCINA = 'luz_cocina'
REF_PULSADOR_A = 'pulsador_a'

class IOT():

    def __init__(self):
        cred = credentials.Certificate(PAHT_CRED)
        firebase_admin.initialize_app(cred, {
            'databaseURL': URL_DB
        })

        self.refHome = db.reference(REF_HOME)

       # self.estructuraInicialDB() # solo ejecutar la primera vez

        self.refLuces = self.refHome.child(REF_LUCES)
        self.refLuzSala = self.refLuces.child(REF_LUZ_SALA)
        self.refLuzCocina = self.refLuces.child(REF_LUZ_COCINA)
        self.refBotones = self.refHome.child(REF_BOTONES)
        self.refPulsadorA = self.refBotones.child(REF_PULSADOR_A)

    def estructuraInicialDB(self):
        self.refHome.set({
            'luces': {
                'luz_sala':True,
                'luz_cocina':True
            },
            'botones':{
                'pulsador_a':True,
                'pulsador_b':True
            }
        })

    def ledControlGPIO(self, estado, led):
        if estado:
            led.on()
            print('LED ON')
        else:
            led.off()
            print('LED OFF')

    def lucesStart(self):

        E, i = [], 0
        R, j = [], 0
    
        estado_anterior_sala = self.refLuzSala.get()
        self.ledControlGPIO(estado_anterior_sala,LED1)
        
        estado_anterior_cocina = self.refLuzCocina.get()
        self.ledControlGPIO(estado_anterior_cocina,LED2)

        E.append(estado_anterior_sala)
        R.append(estado_anterior_cocina)

        while True:
          estado_actual_sala = self.refLuzSala.get()
          E.append(estado_actual_sala)

          estado_actual_cocina = self.refLuzCocina.get()
          R.append(estado_actual_cocina)

          if E[i] != E[-1]:
           self.ledControlGPIO(estado_actual_sala,LED1)

          if R[i] != R[-1]:
           self.ledControlGPIO(estado_actual_cocina,LED2)

          del E[0]
          del R[0]
          
          i = i + i
          j = j + j
          sleep(0.4)

    def pulsador_on(self):
        print('Pulsador On')
        self.refPulsadorA.set(True)

    def pulsador_off(self):
        print('Pulsador Off')
        self.refPulsadorA.set(False)

    def botonesStart(self):
        print('Start btn !')
        BUTTON.when_pressed = self.pulsador_on
        BUTTON.when_released = self.pulsador_off


print ('START !')
iot = IOT()

subproceso_led = Thread(target=iot.lucesStart)
subproceso_led.daemon = True
subproceso_led.start()

subproceso_btn = Thread(target=iot.botonesStart)
subproceso_btn.daemon = True
subproceso_btn.start()
signal.pause()
