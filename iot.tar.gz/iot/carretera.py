import sys
from time import sleep
import RPi.GPIO as GPIO, time
import signal
from gpiozero import LED, Button
from threading import Thread
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db


GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.IN)
LED1 = LED(17)
LED2 = LED(22)

PAHT_CRED = '/home/pi/iot/cred.json'
URL_DB = 'https://conmutacion-final-93db1.firebaseio.com/'
REF_CIUDAD = 'ciudad'
REF_LUCES = 'luces'
REF_SENSORES = 'sensores'
REF_LUZ_FAROLA1 = 'luz_farola1'
REF_LUZ_FAROLA2 = 'luz_farola2'
REF_SENSOR_CONTAMINACION = 'sensor_contaminacion'

class IOT():

    def __init__(self):
        cred = credentials.Certificate(PAHT_CRED)
        firebase_admin.initialize_app(cred, {
            'databaseURL': URL_DB
        })

        self.refHome = db.reference(REF_CIUDAD)

        #self.estructuraInicialDB()

        self.refLuces = self.refHome.child(REF_LUCES)
        self.refLuzFarola1 = self.refLuces.child(REF_LUZ_FAROLA1)
        self.refLuzFarola2 = self.refLuces.child(REF_LUZ_FAROLA2)
        self.refSensores = self.refHome.child(REF_SENSORES)
        self.refSensoresContaminacion = self.refSensores.child(REF_SENSOR_CONTAMINACION)

    def estructuraInicialDB(self):
        self.refHome.set({
            'luces': {
                'luz_farola1':True,
                'luz_farola2':True
            },
            'sensores':{
                'sensor_contaminacion':True
            }
        })

    def ledControlGPIO(self, estado, led):
        if estado:
            led.on()
            print('Farola Encendida')
        else:
            led.off()
            print('Farola Apagada')

    def lucesStart(self):

        E, i = [], 0
        R, j = [], 0

        estado_anterior_farola1 = self.refLuzFarola1.get()
        self.ledControlGPIO(estado_anterior_farola1,LED1)

        estado_anterior_farola2 = self.refLuzFarola2.get()
        self.ledControlGPIO(estado_anterior_farola2,LED2)

        E.append(estado_anterior_farola1)
        R.append(estado_anterior_farola2)

        while True:
          estado_actual_farola1 = self.refLuzFarola1.get()
          E.append(estado_actual_farola1)

          estado_actual_farola2 = self.refLuzFarola2.get()
          R.append(estado_actual_farola2)

          if E[i] != E[-1]:
           self.ledControlGPIO(estado_actual_farola1,LED1)

          if R[i] != R[-1]:
           self.ledControlGPIO(estado_actual_farola2,LED2)

          del E[0]
          del R[0]

          i = i + i
          j = j + j
          sleep(0.4)

    def sensorStart(self):
        # Cuerpo del codigo
        try:
            while True:
                if GPIO.input(18):
                    print("Sin problemas")
                    time.sleep(2)
                    self.refSensoresContaminacion.set(False)
                if GPIO.input(18)!=1:
                    print("GASSSSSS")
                    time.sleep(2)
                    self.refSensoresContaminacion.set(True)
        # Cerramos el script
        except KeyboardInterrupt:
            GPIO.cleanup()


print ('START !')
iot = IOT()

subproceso_led = Thread(target=iot.lucesStart)
subproceso_led.daemon = True
subproceso_led.start()

subproceso_btn = Thread(target=iot.sensorStart)
subproceso_btn.daemon = True
subproceso_btn.start()
signal.pause()
