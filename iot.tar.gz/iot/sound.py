import RPi.GPIO as GPIO
import time

channel = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(channel, GPIO.IN)
GPIO.setup(27, GPIO.OUT)

def callback(channel):
    if GPIO.input(channel):
        GPIO.output(27, True)
        print("Accidente Detectado!")
        time.sleep(1)
        GPIO.output(27, False)

       
    else:
        GPIO.output(27, True)
        print("Accidente Detectado!")
        time.sleep(1)
        GPIO.output(27, False)
        print("Accidente Detectado!")


GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)
GPIO.add_event_callback(channel, callback)

while (True):
    print("Sin Accidentes")
    if (callback(channel)):
        while (True):
             GPIO.output(27, True)
            
            
    time.sleep(1)
    
