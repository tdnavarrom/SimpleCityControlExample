package com.example.citycontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ToggleButton;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    // Write a message to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference refHome = database.getReference("ciudad");
    DatabaseReference refLuces, refSensores, refLuzFarolas, refLuzParque, refLuzCiclo, refSensorChoques;
    ToggleButton btnToggleFarolas, btnToggleParque, btnDesactivarA, btnToggleCiclo;
    TextView textEstadoSensor, textBtnAlarma;
    EditText etpasswd;
    Button btnSubmit;
    TextView result;

    /*
    *
    * Este metodo es lo primero que se ejecuta al abrir la aplicacion
    * los refs.child son para buscar la referencia de esa etiqueta en la base de datos
    * de Firebase y tomar su informacion.
    *
    * Tambien es donde se encuentra la validacion del password para desactivar la alarma
    *
    * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        refLuces = refHome.child("luces");
        refLuzParque = refLuces.child("luz_parque");
        refLuzFarolas = refLuces.child("luz_farolas");
        refLuzCiclo = refLuces.child("luz_ciclo");
        refSensores = refHome.child("sensores");
        refSensorChoques = refSensores.child("sensor_sonido");

        btnToggleParque = (ToggleButton) findViewById(R.id.toggleButtonParque);
        btnToggleParque.setTextOn("APAGAR");
        btnToggleParque.setTextOff("ENCENDER");

        btnToggleFarolas = (ToggleButton) findViewById(R.id.toggleButtonFarolas);
        btnToggleFarolas.setTextOn("APAGAR");
        btnToggleFarolas.setTextOff("ENCENDER");

        btnToggleCiclo = (ToggleButton) findViewById(R.id.toggleButtonCiclo);
        btnToggleCiclo.setTextOn("APAGAR");
        btnToggleCiclo.setTextOff("ENCENDER");

        textBtnAlarma = (TextView) findViewById(R.id.textToggleBtnDesactivarAlarma);
        textBtnAlarma.setVisibility(View.GONE);

        btnDesactivarA = (ToggleButton) findViewById(R.id.desactivarAlarma);
        btnDesactivarA.setVisibility(View.GONE);


        textEstadoSensor = (TextView) findViewById(R.id.textViewSensor);
        result = (TextView) findViewById(R.id.tvResult);


        controlLED(refLuzParque, btnToggleParque);
        controlLED(refLuzFarolas, btnToggleFarolas);
        controlLED(refLuzCiclo, btnToggleCiclo);

        estadoSensor(refSensorChoques, textEstadoSensor);

        btnSubmit = (Button)findViewById(R.id.submit);
        etpasswd   = (EditText)findViewById(R.id.passwordAuth);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get text from EditText name view
                String name = etpasswd.getText().toString();
                name = name.replace(" ","");
                if (name.equals("uribe")){
                    result.setText("Clave Correcta");
                    textBtnAlarma.setVisibility(View.VISIBLE);
                    btnDesactivarA.setVisibility(View.VISIBLE);
                    controlAlarma(refSensorChoques, btnDesactivarA);
                }else{
                    result.setText("Clave Incorrecta");
                }


            }
        });

    }


    /*
    *
    * Metodo que toma como argumento la referencia de la etiqueta de la base de datos,
    * y el boton que se presiono, esto es para cambiar el estado de la referencia.
    * Y poder hacer que se prenda o se apague la luz correspondiente a la etiqueta.
    *
    * */

    private void controlLED(final DatabaseReference refLed, final ToggleButton toggle_btn) {

        toggle_btn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                refLed.setValue(isChecked);
            }
        });

        refLed.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean estado_led = (Boolean) dataSnapshot.getValue();
                toggle_btn.setChecked(estado_led);
                if (estado_led) {
                    toggle_btn.setTextOn("APAGAR");
                } else {
                    toggle_btn.setTextOff("ENCENDER");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }

        });
    }


    /*
     *
     * Metodo que toma como argumento la referencia de la etiqueta alarma de la base de datos ,
     * y el boton que se presiono de la alarma, esto es para cambiar el estado de la referencia.
     * Y poder hacer que se prenda o se apague la luz de la alarma.
     *
     * */

    public void controlAlarma(final DatabaseReference refSensorContaminacion, final ToggleButton toggle_btn) {

        toggle_btn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                refSensorContaminacion.setValue(isChecked);
            }
        });

        refSensorContaminacion.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean estado_led = (Boolean) dataSnapshot.getValue();
                toggle_btn.setChecked(estado_led);
                if (estado_led) {
                    toggle_btn.setTextOn("DESACTIVAR");
                } else {
                    toggle_btn.setTextOff("ACTIVAR");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }

        });
    }


    /*Metodo que nos dice como se encuentra el estado de choque
    * retorna:
    *  True si el sensor a dectado un sonido,
    * false si no ha detectado un sonido*/

    private void estadoSensor(final DatabaseReference refSensorContaminacion, final TextView textEstadoSensor) {

        refSensorContaminacion.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean estado_sensor = (Boolean) dataSnapshot.getValue();
                textEstadoSensor.setText(estado_sensor.toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}
